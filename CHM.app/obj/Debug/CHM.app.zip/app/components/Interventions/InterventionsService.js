(function () {
    "use strict";

    angular.module('CHM').factory('InterventionsService', InterventionsService);

    InterventionsService.$inject = ['$rootScope', '$q', '$http', '$window'];

    function InterventionsService($rootScope, $q, $http, $window) {

        var objInterventionsService = {};

        objInterventionsService.GenerateInterventions = generateInterventions;
        objInterventionsService.GetInterventionsForResident = getInterventionsForResident;
        objInterventionsService.UpdateInterventionsStatus = UpdateInterventionsStatus;
        objInterventionsService.GetInterventions = GetInterventions;
        objInterventionsService.GetStartedInterventionForResident = GetStartedInterventionForResident;
        objInterventionsService.GenerateAdhocInterventions = generateAdhocInterventions;
        objInterventionsService.DeActiveAdhocIntervention = deActiveAdhocIntervention;
        objInterventionsService.UpdategeneratedInterventions = UpdategeneratedInterventions;
        objInterventionsService.DeactiveGeneratedIntervention = DeactiveGeneratedIntervention;
        objInterventionsService.GetInterventionsForCurrentDate = GetInterventionsForCurrentDate;
        return objInterventionsService;

        function generateInterventions(lstActions) {
            return $http.post($rootScope.ApiPath + 'Interventions/GenerateInterventions', lstActions);
        }

        function generateAdhocInterventions(lstActions) {
            return $http.post($rootScope.ApiPath + 'Interventions/GenerateAdhocInterventions', lstActions);
        }
        function getInterventionsForResident(residentId, startDate, endDate) {
            return $http.get($rootScope.ApiPath + 'Interventions/GetInterventionsForResident?residentId=' + residentId + '&startDate=' + startDate + '&endDate=' + endDate);
        }

        function GetInterventionsForCurrentDate(starttodaydate,endtodaydate) {
            return $http.get($rootScope.ApiPath + 'Interventions/GetInterventionsForCurrentDate?starttodaydate=' + starttodaydate + '&endtodaydate=' + endtodaydate);
        }

        function UpdateInterventionsStatus(Interventions) {
            return $http.post($rootScope.ApiPath + 'Interventions/UpdateIntervention', Interventions);
        }
        function GetInterventions(InterventionId) {
            return $http.post($rootScope.ApiPath + 'Interventions/GetIntervention?InterventionId=' + InterventionId);
        }


        function GetStartedInterventionForResident(residentId, startDate, endDate) {
            return $http.get($rootScope.ApiPath + 'Interventions/GetStartedInterventionsForResident?residentId=' + residentId + '&startDate=' + startDate + '&endDate=' + endDate);
        }

        function deActiveAdhocIntervention(lstActions) {
            return $http.post($rootScope.ApiPath + 'Interventions/DeActiveAdhocIntervention', lstActions);
        }


        function UpdategeneratedInterventions(lstActions) {
            return $http.post($rootScope.ApiPath + 'Interventions/UpdateGeneratedInterventions', lstActions);
        }

        function DeactiveGeneratedIntervention(interventionID) {
            return $http.post($rootScope.ApiPath + 'Interventions/DeleteGeneratedIntervention?interventionID=' + interventionID);
        }
    }

}());